Execute the following commands using the terminal to run the logistic_regression.cpp and naive_bayes.cpp files:

$ g++ -std=c++11 logistic_regression.cpp -o logistic_regression
$ ./logistic_regression
$ g++ -std=c++11 naive_bayes.cpp -o naive_bayes
$ ./naive_bayes