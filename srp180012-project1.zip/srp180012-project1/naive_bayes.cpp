#include <chrono>
#include <fstream>
#include <vector>
#include <cmath>
#include <iostream>

using namespace std;

// Method to count the number of people that survived
int count_survived(vector <int> v) {
    int count = 0;
    for (int i = 0; i < v.size(); i++) {
        if (v.at(i) == 1) {
            count++;
        }
    }
    return count;
}

// Method to calculate A-apriori probabilities
vector<double> apriori (vector <int> v) {
    vector<double> p;
    int num_survived = count_survived(v);
    int num_dead = v.size() - num_survived;
    p.push_back(1.0 * num_dead / v.size());
    p.push_back(1.0 * num_survived / v.size());
    return p;
}

// Method to calculate conditional probabilities between variables
double conditional_probability(vector <int> a, int a_val, vector <int> b, int b_val, int size) {
    double count_both = 0;
    double count_a = 0;
    for (int i = 0; i < size; i++) {
        if (a.at(i) == a_val && b.at(i) == b_val) {
            count_both++;
        }
        if (a.at(i) == a_val) {
            count_a++;
        }
    }
    count_both /= size;
    count_a /= size;
    return count_both/count_a;
}

// Method to calculate mean age of people who survived/not survived
double mean(vector <double> age, vector <int> survived, int val, int size) {
    double sum = 0;
    int count = 0;
    for (int i = 0; i < size; i++) {
        if (survived.at(i) == val) {
            sum += age.at(i);
            count++;
        }
    }
    return sum/count;
}

// Method  to calculate standard deviation age who survived/not survived
double stdev(vector <double> age, vector<int> survived, int val, int size) {
    double ans = 0;
    double avg = mean(age, survived, val, size);
    int count = 0;
    for (int i = 0; i < size; i++) {
        if (survived.at(i) == val) {
            ans += pow(age.at(i) - avg, 2);
            count++;
        }
    }
    return sqrt(ans/count);
}

// Method to calculate likelihood of age
double calc_age_lh(double v, double mean_v, double var_v) {
    return 1 / sqrt(2 * 3.14159265 * var_v) * exp(-1 * (pow(v-mean_v, 2)) / (2 * var_v));
}

// Method to calculate raw probabilities based on training data conditional probabilities and testing data values
vector<double> calc_raw_prob(vector<vector<double> > pclass_vector, vector<vector<double> > sex_vector, vector<vector<double> > age_vector, vector<double> apriori_vector, int pclass, int sex, double age) {
    age = floor(age);

    double num_s = (pclass_vector.at(1).at(pclass - 1)) * (sex_vector.at(1).at(sex)) * (apriori_vector.at(1)) * (calc_age_lh(age, age_vector.at(1).at(0), pow(age_vector.at(1).at(1), 2)));
    double num_p = (pclass_vector.at(0).at(pclass - 1)) * (sex_vector.at(0).at(sex)) * (apriori_vector.at(0)) * (calc_age_lh(age, age_vector.at(0).at(0), pow(age_vector.at(0).at(1), 2)));

    double denominator = num_s + num_p;

    vector <double> ans;
    ans.push_back(num_s/denominator);
    ans.push_back(num_p/denominator);

    return ans;
}

// Main method
int main() {
    ifstream inFS;                                              // Initialize input file stream object
    string line;
    string dummy_in, pclass_in, survived_in, sex_in, age_in;    // String to read in strings of values

    // Initialize vectors
    int pclass[1046];
    int survived[1046];
    int sex[1046];
    double age[1046];

    inFS.open("titanic_project.csv");
    if (!inFS.is_open()) {
        cout << "Could not open file titanic_project.csv" << endl;
        return 1;
    }

    // Read and print headings debug statement
    getline(inFS, line);
    int num = 0;
    while(inFS.good()) {
        // Read next line and parse by comma into strings
        getline(inFS, dummy_in, ',');
        getline(inFS, pclass_in, ',');
        getline(inFS, survived_in, ',');
        getline(inFS, sex_in, ',');
        getline(inFS, age_in, '\n');

        // Add int values to respective vectors
        pclass[num] = (stoi(pclass_in));
        survived[num] = (stoi(survived_in));
        sex[num] = (stoi(sex_in));
        age[num] = (stod(age_in));

        // cout << pclass[num] << " " << survived[num] << " " << sex[num] << " " << age[num] << endl;
        num++;
    }

    // Initialize training set
    vector <int> pclass_train;
    vector <int> survived_train;
    vector <int> sex_train;
    vector <double> age_train;

    // Initialize testing set
    int pclass_test[146];
    int survived_test[146];
    int sex_test[146];
    double age_test[146];

    // Split into training and testing sets
    for (int i = 0; i < 900; i++) {
        pclass_train.push_back(pclass[i]);
        survived_train.push_back(survived[i]);
        sex_train.push_back(sex[i]);
        age_train.push_back(age[i]);
    }

    for (int i = 900; i < 1046; i++) {
        pclass_test[i - 900] = pclass[i];
        survived_test[i - 900] = survived[i];
        sex_test[i - 900] = sex[i];
        age_test[i - 900] = age[i];
    }

    // Declare vectors to hold probabilities
    vector <double> apriori_final;

    vector <vector <double> > pclass_final;
    vector <double> pclass_final_negative;
    vector <double> pclass_final_positive;

    vector <vector <double> > sex_final;
    vector <double> sex_final_negative;
    vector <double> sex_final_positive;

    vector <vector <double> > age_final;
    vector <double> age_final_negative;
    vector <double> age_final_positive;

    // Start clock
    auto start = chrono::high_resolution_clock::now();

    // Call apriori() and assign to apriori_final
    apriori_final = apriori(survived_train);

    // Find conditional probabilities of pclass_train * not survived and assign to pclass_final_negative
    pclass_final_negative.push_back(conditional_probability(survived_train, 0, pclass_train, 1, 900));
    pclass_final_negative.push_back(conditional_probability(survived_train, 0, pclass_train, 2, 900));
    pclass_final_negative.push_back(conditional_probability(survived_train, 0, pclass_train, 3, 900));

    // Find conditional probabilities of pclass_train * survived and assign to pclass_final_positive
    pclass_final_positive.push_back(conditional_probability(survived_train, 1, pclass_train, 1, 900));
    pclass_final_positive.push_back(conditional_probability(survived_train, 1, pclass_train, 2, 900));
    pclass_final_positive.push_back(conditional_probability(survived_train, 1, pclass_train, 3, 900));

    // Add pclass_final_negative and pclass_final_positive to pclass_final
    pclass_final.push_back(pclass_final_negative);
    pclass_final.push_back(pclass_final_positive);

    // Find conditional probabilities of sex_train * not survived and assign to sex_final_negative
    sex_final_negative.push_back(conditional_probability(survived_train, 0, sex_train, 0, 900));
    sex_final_negative.push_back(conditional_probability(survived_train, 0, sex_train, 1, 900));

    // Find conditional probabilities of sex_train * survived and assign to sex_final_positive
    sex_final_positive.push_back(conditional_probability(survived_train, 1, sex_train, 0, 900));
    sex_final_positive.push_back(conditional_probability(survived_train, 1, sex_train, 1, 900));

    // Add sex_final_negative and sex_final_positive to sex_final
    sex_final.push_back(sex_final_negative);
    sex_final.push_back(sex_final_positive);

    // Find conditional probabilities of age_train * not survived and assign to age_final_negative
    age_final_negative.push_back(mean(age_train, survived_train, 0, 900));
    age_final_negative.push_back(stdev(age_train, survived_train, 0, 900));

    // Find conditional probabilities of age_train * survived and assign to age_final_positive
    age_final_positive.push_back(mean(age_train, survived_train, 1, 900));
    age_final_positive.push_back(stdev(age_train, survived_train, 1, 900));

    // Add age_final_negative and age_final_positive to age_final
    age_final.push_back(age_final_negative);
    age_final.push_back(age_final_positive);

    // Stop clock
    auto stop = chrono::high_resolution_clock::now();

    // Calculate running time
    chrono::duration<double> elapsed_sec = stop - start;

    cout << "---------------------------------------" << endl;
    cout << "A-priori probabilities:" << endl;
    cout << "Y" << endl;
    cout << "\t0\t1" << endl;
    cout << "\t" << apriori_final.at(0) << "\t" << apriori_final.at(1) << endl;
    cout << "---------------------------------------" << endl;
    cout << "Conditional probabilities:" << endl;
    cout << "\tpclass" << endl;
    cout << "Y\t1\t\t2\t\t3" << endl;
    cout << "0\t" << pclass_final.at(0).at(0) << "\t" << pclass_final.at(0).at(1) << "\t\t" << pclass_final.at(0).at(2) << endl;
    cout << "1\t" << pclass_final.at(1).at(0) << "\t" << pclass_final.at(1).at(1) << "\t" << pclass_final.at(1).at(2) << endl;
    cout << endl;
    cout << "\tsex" << endl;
    cout << "Y\tfemale\t\tmale" << endl;
    cout << "0\t" << sex_final.at(0).at(0) << "\t" << sex_final.at(0).at(1) << "\t\t" << endl;
    cout << "1\t" << sex_final.at(1).at(0) << "\t" << sex_final.at(1).at(1) << "\t" << endl;
    cout << endl;
    cout << "\tage" << endl;
    cout << "Y\t0\t\t1" << endl;
    cout << "0\t" << age_final.at(0).at(0) << "\t\t" << age_final.at(0).at(1) << endl;
    cout << "1\t" << age_final.at(1).at(0) << "\t\t" << age_final.at(1).at(1) << endl;
    cout << "---------------------------------------" << endl;

    // Declare test variables
    double TP = 0;
    double FP = 0;
    double FN = 0;
    double TN = 0;

    // Predict the test variables
    for (int i = 0; i < 146; i++) {
        // Calculate the raw probability based on the conditional probabilities and test data
        vector <double> probs = calc_raw_prob(pclass_final, sex_final, age_final, apriori_final, pclass_test[i], sex_test[i], age_test[i]);
        double prob1 = probs.at(0);
        double prob2 = probs.at(1);

//        cout << prob1 << " " << prob2 << endl;

        // Calculate the predictions
        int pred = (prob1 > 0.5) ? 1 : 0;
        int real = survived_test[i];

        // Increment the test variables
        if (pred == 1 && real == 1) {
            TN++;
        } else if (pred == 1 && real == 0) {
            FN++;
        } else if (pred == 0 && real == 1) {
            FP++;
        } else {
            TP++;
        }
    }

    // Print confusion matrix
    cout << "pred" << "\t0\t1" << endl;
    cout << "0\t" << TP << "\t" << FP << endl;
    cout << "1\t" << FN << "\t" << TN << endl;
    cout << "---------------------------------------" << endl;

    // Calculate the metrics
    double accuracy = (TP + TN) / (TP + FP + FN + TN);
    double sensitivity = TP / (TP + FN);
    double specificity = TN / (TN + FP);

    // Print the metrics
    cout << "Accuracy = " << accuracy << endl;
    cout << "Sensitivity = " << sensitivity << endl;
    cout << "Specificity = " << specificity << endl << endl;

    // Print the running time
    cout << "Run time = " << elapsed_sec.count() << endl;
    cout << "---------------------------------------" << endl;
}
